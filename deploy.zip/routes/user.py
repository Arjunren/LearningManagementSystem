from flask import Blueprint, render_template, session, request, flash, redirect, url_for, jsonify
from utils.decorators import login_required
from services.course_service import get_user_enrollments, get_course
from services.auth_service import get_user_by_id, user_db, verify_password, hash_password
from services.notification_service import get_user_notifications, mark_as_read, mark_all_as_read

bp = Blueprint('user', __name__, url_prefix='/user')

@bp.route('/dashboard')
@login_required
def dashboard():
    user = get_user_by_id(session['user_id'])
    enrollments = get_user_enrollments(session['user_id'])
    
    courses_in_progress = []
    completed_courses = []
    
    for enr in enrollments:
        course = get_course(enr['course_id'])
        if course:
            enr_data = {'enrollment': enr, 'course': course}
            if enr['status'] == 'completed':
                completed_courses.append(enr_data)
            else:
                courses_in_progress.append(enr_data)

    notifications = get_user_notifications(session['user_id'])
    unread_count = sum(1 for n in notifications if not n['read'])
                
    return render_template('user/dashboard.html', 
                           user=user, 
                           in_progress=courses_in_progress,
                           completed=completed_courses,
                           notifications=notifications,
                           unread_count=unread_count)

@bp.route('/notifications/read/<notif_id>', methods=['POST'])
@login_required
def read_notification(notif_id):
    success = mark_as_read(notif_id, session['user_id'])
    return jsonify({'success': success})

@bp.route('/notifications/read_all', methods=['POST'])
@login_required
def read_all_notifications():
    count = mark_all_as_read(session['user_id'])
    return jsonify({'success': True, 'count': count})

@bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    user = get_user_by_id(session['user_id'])
    
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_profile':
            full_name = request.form.get('full_name')
            user_db.update(user['id'], {'full_name': full_name})
            session['user_name'] = full_name
            flash("Profile updated successfully.", "success")
            
        elif action == 'change_password':
            current_pw = request.form.get('current_password')
            new_pw = request.form.get('new_password')
            confirm_pw = request.form.get('confirm_password')
            
            if not verify_password(current_pw, user['password_hash']):
                flash("Current password is incorrect.", "danger")
            elif new_pw != confirm_pw:
                flash("New passwords do not match.", "danger")
            else:
                user_db.update(user['id'], {'password_hash': hash_password(new_pw)})
                flash("Password changed successfully.", "success")
                
        return redirect(url_for('user.settings'))
        
    return render_template('user/settings.html', user=user)
