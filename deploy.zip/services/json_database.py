import os
import json
import uuid
import tempfile
from config import Config

class JSONDatabase:
    def __init__(self, table_name):
        self.table_name = table_name
        self.dir_path = os.path.join(Config.DATA_DIR, table_name)
        os.makedirs(self.dir_path, exist_ok=True)

    def _get_file_path(self, record_id):
        return os.path.join(self.dir_path, f"{record_id}.json")

    def generate_id(self, prefix=""):
        return f"{prefix}_{uuid.uuid4().hex[:12]}" if prefix else uuid.uuid4().hex[:12]

    def create(self, data, record_id=None, prefix=""):
        """Creates a new record with a unique ID."""
        if not record_id:
            record_id = self.generate_id(prefix)
        data['id'] = record_id
        self.save(record_id, data)
        return record_id

    def save(self, record_id, data):
        """Saves data to a JSON file atomically."""
        file_path = self._get_file_path(record_id)
        # Atomic write: write to temp file, then replace
        fd, temp_path = tempfile.mkstemp(dir=self.dir_path)
        with os.fdopen(fd, 'w') as f:
            json.dump(data, f, indent=4)
        os.replace(temp_path, file_path)

    def get(self, record_id):
        """Reads a record by ID. Returns None if not found."""
        file_path = self._get_file_path(record_id)
        if not os.path.exists(file_path):
            return None
        with open(file_path, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return None

    def get_all(self):
        """Returns all records in the table."""
        records = []
        if not os.path.exists(self.dir_path):
            return records
            
        for filename in os.listdir(self.dir_path):
            if filename.endswith(".json"):
                record_id = filename[:-5]
                record = self.get(record_id)
                if record:
                    records.append(record)
        return records

    def update(self, record_id, updates):
        """Updates an existing record with new data."""
        record = self.get(record_id)
        if record:
            record.update(updates)
            self.save(record_id, record)
            return True
        return False

    def delete(self, record_id):
        """Deletes a record."""
        file_path = self._get_file_path(record_id)
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        return False

    def find(self, **kwargs):
        """Finds records matching the given key-value pairs."""
        results = []
        for record in self.get_all():
            match = True
            for key, value in kwargs.items():
                if record.get(key) != value:
                    match = False
                    break
            if match:
                results.append(record)
        return results

    def find_one(self, **kwargs):
        """Finds the first record matching the given key-value pairs."""
        for record in self.get_all():
            match = True
            for key, value in kwargs.items():
                if record.get(key) != value:
                    match = False
                    break
            if match:
                return record
        return None
