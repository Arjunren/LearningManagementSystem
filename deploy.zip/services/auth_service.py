from werkzeug.security import generate_password_hash, check_password_hash
from services.json_database import JSONDatabase
import datetime

user_db = JSONDatabase('users')
admin_db = JSONDatabase('admins')

def hash_password(password):
    return generate_password_hash(password)

def verify_password(password, hashed_password):
    return check_password_hash(hashed_password, password)

def create_user(full_name, email, password, role="student"):
    if user_db.find_one(email=email) or admin_db.find_one(email=email):
        return None, "Email already exists."
        
    user_data = {
        'full_name': full_name,
        'email': email,
        'password_hash': hash_password(password),
        'email_verified': True, # Set to True since they verified OTP
        'role': role,
        'created_at': datetime.datetime.utcnow().isoformat(),
        'updated_at': datetime.datetime.utcnow().isoformat()
    }
    
    user_id = user_db.create(user_data, prefix="user")
    return user_id, "User created successfully."

def authenticate(email, password, is_admin=False):
    db = admin_db if is_admin else user_db
    user = db.find_one(email=email)
    
    if user and verify_password(password, user['password_hash']):
        return user
    return None
    
def get_user_by_id(user_id, is_admin=False):
    db = admin_db if is_admin else user_db
    return db.get(user_id)
